 <div class="col-left-50">
          <div class="page-hd">Reports</div>
        </div><!-- end-col-left-50 -->
        
        <div class="col-right-50">
          <ul class="listing">
            <li>
              <select class="styled">
                <option>All Pets</option>
                <option>two</option>
                <option>something</option>
                <option>4</option>
                <option>5</option>
              </select>
            </li>
          </ul>
        </div><!-- end-col-right-50 -->
        
<div class="clear"></div>
        
        <div class="timeline-add-section">
          <p><i class="fa fa-bar-chart fa-5x"></i> </p>
          <p><big><b>No data to show</b></big></p>
          <p>You must add a Surehub and Pet Door to see activity reports.</p>
          <p><a href="#" class="button iris-blue"><i class="fa fa-plus"></i>Add SureHub</a></p>
        </div>