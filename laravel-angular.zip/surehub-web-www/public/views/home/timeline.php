<div class="col-left-50">
          <div class="page-hd">Timeline</div>
        </div><!-- end-col-left-50 -->
        
        <div class="col-right-50">
          <ul class="listing">
            <li>
              <input type="file" name="file-1[]" id="file-1" class="inputfile inputfile-1" data-multiple-caption="{count} files selected" multiple />
              <label for="file-1"><i class="fa fa-camera"></i><span>Add Photo</span></label>
            </li>
            <li>
              <select class="styled">
                <option>All Pets</option>
                <option>two</option>
                <option>something</option>
                <option>4</option>
                <option>5</option>
              </select>
            </li>
          </ul>
        </div><!-- end-col-right-50 -->
        
<div class="clear"></div>
        
        <div class="timeline-add-section">
          <p><img src="images/add-pet-door.jpg" alt="user" /> </p>
          <p><big><b>Add Pet Door</b></big></p>
          <p><a href="#" class="button iris-blue"><i class="fa fa-plus"></i>Add Pet Door</a></p>
        </div>
        <div class="a-created">
          <ul>
          	<li>
              <div class="a-cont"> <span class="user-icon sky-blue-bg"><i class="fa fa-user"></i></span> <span class="user-text">
                <div class="hd">Sure Hub added</div>
                <div class="a-cont-da">Today 9:01am</div>
                </span> </div>
            </li>
            <li>
              <div class="a-cont"> <span class="user-icon grey-bg"><i class="fa fa-user"></i></span> <span class="user-text">
                <div class="hd">Accout created!</div>
                <div class="a-cont-da">Today 8:12pm</div>
                </span> </div>
            </li>
          </ul>
        </div><!-- end-a-created --> 
      <div class="clear"></div>