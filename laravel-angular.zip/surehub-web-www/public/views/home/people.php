 <div class="col-left-50">
          <div class="page-hd">People</div>
        </div><!-- end-col-left-50 -->
        
        <div class="col-right-50">
          <ul class="listing">
            <li>
              <select class="styled">
                <option>All Pets</option>
                <option>two</option>
                <option>something</option>
                <option>4</option>
                <option>5</option>
              </select>
            </li>
          </ul>
        </div><!-- end-col-right-50 -->
        
<div class="clear"></div>
        
        <div class="timeline-add-section">
          <p><i class="fa fa-users fa-5x"></i> </p>
          <p><big><b>Invite Friends and family!</b></big></p>
          <p>Invite your spouse, children, pet sitter or just friends and family that<br/> cloud be interested in seeing what your pets are up to!.</p>
          <p><a href="#" class="button iris-blue"><i class="fa fa-plus"></i>Add SureHub</a></p>
        </div>
        <div class="col-left-30">
          <div class="hd">Invite by URL</div>
          <div class="m10">
            <input type="text" class="input" onfocus="javascript:if(this.value=='Email address') this.value = '';" onblur="javascript:if(this.value=='') this.value = 'Email address';"  
            value="Email address" />
          </div>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a 
            galley of type and scrambled it to make a type specimen book.</p>
        </div><!-- end-col-left-30 -->
        
        <div class="col-right-70">
          <div class="hd">Invite via email</div>
          <div class="m10">
            <input type="text" class="input" onfocus="javascript:if(this.value=='Enter email addresses, separated by commas') this.value = '';" 
            onblur="javascript:if(this.value=='') this.value = 'Enter email addresses, separated by commas';" value="Enter email addresses, separated by commas" />
          </div>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
        </div><!-- end-col-left-70 --> 
<div class="clear"></div>