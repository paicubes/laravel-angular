	<div class="page-hd">People</div>
        <P>Choose from the below locking options.</P>
        <div class="col-left-70">
        <div class="lock-col">
        	<div class="lock-col-cont">
            	<div class="lock-col-img green"><i class="fa fa-home"></i></div>
                <div class="lock-col-text">Pet Door is set to lock inside, preventing pets from leavin the house, any pets that are outside will be allowed inside, but not out again.</div>
            </div>
            <div class="lock-col-but">
            	<a href="#" class="button-l dark-grey">Set Timer..</a>
                <a href="#" class="button-l iris-blue">Unlock</a>
            </div>
            <div class="clear"></div>  
        </div><!-- end-lock-col -->
      
        <h3>Curfew Mode</h3>
        <p>You can set the door to keep pets in at specific times in the day.</p>
        <p align="right"> <input type="checkbox" name="" value="" /> Enable Curfew</p>
        </div><!-- end-col-left-70 -->
<div class="clear"></div>