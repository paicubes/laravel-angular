// public/js/controllers/mainCtrl.js

angular.module('sureflap').controller('mainCtrl', function($scope, $http) {
console.log("mainCtrl");
});