// public/js/controllers/NavController.js

var sureflapApp=angular.module('sureflap')
	.controller('NavController', function($scope, $http,$location, $rootScope,user,$state) { 
		$rootScope.bodyClass="";
		$scope.acitveNav=true;
		$scope.$state = $state;
		console.log($state.includes("lock"));
			
		
	});